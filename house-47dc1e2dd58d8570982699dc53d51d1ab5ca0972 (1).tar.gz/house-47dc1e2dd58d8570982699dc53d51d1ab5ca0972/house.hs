{-# LANGUAGE LambdaCase #-}

-- | Command-line tool to interact with house.

import Control.Concurrent.STM
import System.IO
import System.Environment
import System.Exit
import Data.List
import Text.Read (readMaybe)
import qualified Data.Map.Strict as M

import Sensors
import DataUnits
import WebServers
import Automation.Constants
import Epsolar
import Darksky
import qualified Batteries
import Utility.HumanTime

main :: IO ()
main = getArgs >>= go
  where
	go ("watch":[]) = watch $ \l -> do
		putStrLn l
		hFlush stdout
	go ("watch":f:[]) = watch (writeFile f)
	go ("stream":[]) = streamSensors
	go ("inverter":l) = overrideOf InverterOverride l (hours 12)
	go ("fridge":l) = overrideOf FridgeOverride l (hours 8)
	go ("drives":l) = overrideOf RemovableDrivesOverride l (hours 12)
	go ("kitchen":l) = overrideOf KitchenCounterOutletOverride l (hours 4)
	go ("spring":l) = overrideOf SpringPumpOverride l (days 7)
	go ("springruncycle":l) = runCycle SpringPumpRunCycle l
	go _ = usage

	minutes n = n * 60
	hours n = 60 * minutes n
	days n = 24 * hours n
	
usage :: IO ()
usage = do
	hPutStrLn stderr $ unwords
		 [ "Usage: house watch [file] | stream"
		 , "| (inverter|fridge|kitchen|spring|drives) (on|off|auto) duration"
		 , "| springruncycle onminutes offminutes"
		 ]
	exitWith (ExitFailure 1)

overrideOf :: (Override PowerSetting -> SensedValue) -> [String] -> Int -> IO ()
overrideOf mk (v:n:[]) maxoverrideduration = case override of
	Right o@(OverrideSeconds nsecs _)
		| nsecs > maxoverrideduration ->
			error "duration is too long to be safe!"
		| otherwise -> send (mk o)
	Right DisableOverride -> return ()
	Left e -> do
		hPutStrLn stderr e
		usage
  where
	override = OverrideSeconds
		<$> (fromIntegral . durationSeconds <$> parseDuration n)
		<*> parseps v
	parseps "on" = Right (PowerSetting True)
	parseps "off" = Right (PowerSetting False)
	parseps _ = Left "expected on|off"
overrideOf mk ("auto":[]) _ = send (mk DisableOverride)
overrideOf _ _ _ = usage

runCycle :: (RunCycle -> SensedValue) -> [String] -> IO ()
runCycle mk (on:off:[]) = case (readMaybe on, readMaybe off) of
	(Just non, Just noff) -> send $ mk $
		OnOffRunCycle { onMinutes = non, offMinutes = noff }
	_ -> do
		hPutStrLn stderr "Expected number of minutes on followed by number of minutes off."
		usage
runCycle _ _ = usage

send :: SensedValue -> IO ()
send v = do
	ok <- postSensedValue v
	if ok
		then return ()
		else error "failed communicating with house"

streamSensors :: IO ()
streamSensors = streamPollerWebserverReconnect $ \case
	Left e -> do
		putStrLn e
		hFlush stdout
	Right v -> do
		print v
		hFlush stdout

watch :: (String -> IO ()) -> IO ()
watch callback = do
	sv <- newTVarIO (M.empty, "")
	streamPollerWebserverReconnect $ \case
		Left _e -> callback "x"
		Right v -> do
			(m, l) <- atomically (readTVar sv)
			let k = keySensedValue' v
			let m' = M.insert k v m
			let l' = renderStatus m'
			if l /= l'
				then do
					callback l'
					atomically $ writeTVar sv (m', l')
				else atomically $ writeTVar sv (m', l)

renderStatus :: M.Map KeySensedValue SensedValue -> String
renderStatus m = concat
	[ fmt housestatus id ""
	, fmt batterypercent (showDoublePrecision 0) (batteryvoltpercent ++ "% ")
	, fmt trimetricvolts (showDoublePrecision 2) "v "
	, if ccinputwatts >= Just 1
		then fmt ccinputwatts (showDoublePrecision 0) $ 
			case ccchargingstatus of
				Just Float -> "⇝"
				Just Boost -> "↗"
				Just Equalization -> "="
				Just NoCharging -> "!"
				Nothing -> "?"
		else ""
	, fmt houseusingwatts (showDoublePrecision 0) "W "
	, fmt dailykwh (showDoublePrecision 2) "kwh "
	, fmt pumpstatus id ""
	, fmt porchtemperature (show . celsiusToFahrenheit) ""
	, case fridgetemperature of
		Just t -> 
			let (Delta d) = rangeDelta t fridgeAllowedTemp
			    fd = celsiusToFahrenheit d - 32
			    s = concat
			    	[ if fd > 0 then "+" else ""
				, takeWhile (/= '.') (show fd)
				]
			in if s == "0"
				then ""
				else "[" ++ s ++ "]"
		Nothing -> "[?]"
	, "°F "
	, case neareststorm of
		Just OverheadStorm -> case preciprate of
			Just (InchesPerHour iph)
				| iph >= 0.01 -> emoji RainCloud ++
					showDoublePrecision 2 iph ++ "i/h"
			_ -> emoji RainCloud
		Just (NearbyStorm (Miles mi) bearing)
			| mi <= 10 -> concat
				[ emoji RainCloud
				, compassBearing bearing
				, showDoublePrecision 0 mi
				, "mi"
				, " "
				]
		_ -> case cloudcover of
			Just (Percentage p) ->
				emoji Cloud ++ showDoublePrecision 0 p ++ "%"
			Nothing -> ""
	]
  where
	fmt v f s = maybe "?" f v ++ s
	
	get f = M.lookup (keySensedValue f) m
	with f extract = extract =<< get f
	(housestatus, pumpstatus) = case get AutomationOverallStatus of
		Just (AutomationOverallStatus l) ->
			let (h, p) = partition isHouseStatus l
			    ret = Just . concatMap statusGlyph
			in (ret h, ret p)
		_ -> (Nothing, Nothing)
	batterypercent = with TrimetricBatteryPercent $ \case
		TrimetricBatteryPercent (Just (Percentage p)) -> Just p
		_ -> Nothing
	trimetricwatts = with TrimetricBatteryWatts $ \case
		TrimetricBatteryWatts (Just (Watts p)) -> Just p
		_ -> Nothing
	trimetricvolts = with TrimetricBatteryVolts $ \case
		TrimetricBatteryVolts (Just (Volts p)) -> Just p
		_ -> Nothing
	ccinputwatts = with CcInputWatts $ \case
		CcInputWatts (Just (Watts p)) -> Just p
		_ -> Nothing
	ccchargingstatus = with CcStatusCode $ \case
		CcStatusCode (Just c) -> Just (chargingStatus c)
		_ -> Nothing
	-- The watts that the house is using, not including any that
	-- are being used to charge the battery.
	houseusingwatts = case ccinputwatts of
		Just w -> (w -) <$> trimetricwatts
		Nothing -> trimetricwatts
	dailykwh = with CcKWHGeneratedToday $ \case
		CcKWHGeneratedToday (Just (KWH p)) -> Just p
		_ -> Nothing
	porchtemperature = with PorchTemperature $ \case
		PorchTemperature (Just t) -> Just t
		_ -> Nothing
	fridgetemperature = with FridgeTemperature $ \case
		FridgeTemperature (Just t) -> Just t
		_ -> Nothing
	cloudcover = with ForecastCloudCover $ \case
		ForecastCloudCover (Just t) -> Just t
		_ -> Nothing
	preciprate = with ForecastPrecipRate $ \case
		ForecastPrecipRate (Just t) -> Just t
		_ -> Nothing
	neareststorm = with ForecastNearestStorm $ \case
		ForecastNearestStorm (Just d) -> Just d
		_ -> Nothing
	
	-- Calculating battery percentage from voltage can be more accurate
	-- on the low end, but with less granularity and only when it's
	-- night or at least when the charge controller is not pushing up the
	-- voltage much. Since a momentary voltage sag due to high load makes
	-- it innaccruate, only display when it's higher than the trimetric's
	-- value. The trimetric tends low.
	batteryvoltpercent
		| ccinputwatts > Just 100 = ""
		| otherwise =
			case (trimetricvolts, batterypercent) of
				(Just v, Just bp)
					| bp > 30 -> ""
					| otherwise -> 
						let Percentage p = Batteries.voltsToPercentageSmooth (Volts v)
						    p' = floor p :: Int
						in if p' <= floor bp
							then ""
							else "-" ++ show p'
				_ -> ""

isHouseStatus :: Status -> Bool
isHouseStatus (SpringPumpStatus _) = False
isHouseStatus _ = True

statusGlyph :: Status -> String
statusGlyph LowPower = emoji WarningSign
statusGlyph Sunny = emoji HappySun
statusGlyph (InverterStatus (SetTo (PowerSetting True))) = emoji SineWave
statusGlyph (InverterStatus (SetTo (PowerSetting False))) = "✘"
statusGlyph (InverterStatus (Overridden (PowerSetting True))) = 
	emoji SineWave ++ "!"
statusGlyph (InverterStatus (Overridden (PowerSetting False))) = "✘!"
statusGlyph (InverterStatus NotKnown) = "?"
statusGlyph (FridgeStatus (SetTo (PowerSetting True))) = emoji SnowFlake
statusGlyph (FridgeStatus (Overridden (PowerSetting True))) =
	emoji SnowFlake ++ "!"
statusGlyph (FridgeStatus _) = ""
statusGlyph (FridgeThoughts _) = ""
statusGlyph (KitchenCounterOutletStatus (PowerSetting True)) = emoji KitchenSink
statusGlyph (KitchenCounterOutletStatus (PowerSetting False)) = ""
statusGlyph (RemovableDrivesStatus (PowerSetting True)) = emoji Power
statusGlyph (RemovableDrivesStatus (PowerSetting False)) = ""
statusGlyph (SpringPumpStatus (PowerSetting True)) = emoji Pump
statusGlyph (SpringPumpStatus (PowerSetting False)) = ""

data Emoji = SatelliteDish | SnowFlake | SineWave | HappySun | WarningSign
	| RainCloud | Cloud | Power | Pump | KitchenSink

emoji :: Emoji -> String
emoji SatelliteDish = "📡 "
emoji SnowFlake = "❄"
emoji SineWave = "∿"
-- ghc does not like the unicde power symbol
emoji Power = "\9211"
emoji HappySun = "🌞"
emoji WarningSign = "⚠️"
emoji RainCloud = "🌧️"
emoji Cloud = "☁️"
emoji Pump = "🚰"
-- sadly, emojis and unicode left out the kitchen sink
emoji KitchenSink = "🍳"

compassBearing :: AbsoluteBearing -> String
compassBearing (AbsoluteBearing b)
	| b < 22.5 = "n"
	| b < 67.5 = "ne"
	| b < 112.5 = "e"
	| b < 157.5 = "se"
	| b < 202.5 = "s"
	| b < 247.5 = "sw"
	| b < 302.5 = "w"
	| b < 347.5 = "nw"
	| otherwise = "N"
