{-# LANGUAGE GADTs, DeriveGeneric, DeriveFunctor, FlexibleInstances #-}

module Sensors where

import Data.Aeson
import GHC.Generics
import Data.Time.Clock
import Data.Time.Calendar

import DataUnits
import Epsolar
import DhcpClient
import qualified Trimetric
import Darksky

-- | A value read from a sensor.
-- May contain Nothing if the sensor is not available for some reason.
data SensedValue where
	CcInputVolts :: Maybe Volts -> SensedValue
	CcInputAmps :: Maybe Amps -> SensedValue
	CcInputWatts :: Maybe Watts -> SensedValue
	CcOutputVolts :: Maybe Volts -> SensedValue
	CcOutputAmps :: Maybe Amps -> SensedValue
	CcTemperature :: Maybe Temperature -> SensedValue
	CcBatteryPercent :: Maybe Percentage -> SensedValue
	CcBatteryAmps :: Maybe Amps -> SensedValue
	CcMaxInputVoltsToday :: Maybe Volts -> SensedValue
	CcMaxBatteryVoltsToday :: Maybe Volts -> SensedValue
	CcMinBatteryVoltsToday :: Maybe Volts -> SensedValue
	CcKWHGeneratedToday :: Maybe KWH -> SensedValue
	CcKWHGeneratedTotal :: Maybe KWH -> SensedValue
	CcStatusCode :: Maybe EpsolarStatusCode -> SensedValue
	BatteryTemperature :: Maybe Temperature -> SensedValue
	PorchTemperature :: Maybe Temperature -> SensedValue
	InverterTemperature :: Maybe Temperature -> SensedValue
	SlabTemperature :: Maybe Temperature -> SensedValue
	HallTemperature :: Maybe Temperature -> SensedValue
	HallHumidity :: Maybe RelativeHumidity -> SensedValue
	FridgeTemperature :: Maybe Temperature -> SensedValue
	FridgeAuxTemperature :: Maybe Temperature -> SensedValue
	SpareProbeTemperature :: Maybe Temperature -> SensedValue
	ForecastHumidity :: Maybe RelativeHumidity -> SensedValue
	ForecastCloudCover :: Maybe Percentage -> SensedValue
	ForecastNearestStorm :: Maybe StormLocation -> SensedValue
	ForecastPrecipRate :: Maybe InchesPerHour -> SensedValue
	DhcpClients :: [DhcpClient]-> SensedValue
	TrimetricBatteryPercent :: Maybe Percentage -> SensedValue
	TrimetricBatteryVolts :: Maybe Volts -> SensedValue
	TrimetricBatteryWatts :: Maybe Watts -> SensedValue
	TrimetricCCStatusCode :: Maybe Trimetric.CCStatusCode -> SensedValue

	-- Count of number of sensor failures since the poller was last started.
	SensorFailures :: Integer -> SensedValue

	-- The automation sends these back to the poller.
	AutomationOverallStatus :: [Status] -> SensedValue
	AutomationFridgeRuntimeToday :: (Hours, Maybe Day) -> SensedValue
	AutomationFridgeRunDuration :: Minutes -> SensedValue
	FridgeRelaySetTo :: PowerSetting -> SensedValue
	KitchenCounterOutletRelaySetTo :: PowerSetting -> SensedValue
	RemovableDrivesRelaySetTo :: PowerSetting -> SensedValue
	UsbHubsRelaySetTo :: PowerSetting -> SensedValue

	-- Did an attempt to control the charge controller's load work?
	CcLoadControlWorking :: Bool -> SensedValue
	-- Used by automation to control the charge controller's load.
	CcLoadSetTo :: PowerSetting -> SensedValue
	-- Set by user to override control of the charge controller's load.
	CcLoadOverride :: Override PowerSetting -> SensedValue
	-- Set by user to override the fridge automation temporarily.
	FridgeOverride :: Override PowerSetting -> SensedValue
	-- Set by user to override the automation of the inverter's
	-- power temporarily.
	InverterOverride :: Override PowerSetting -> SensedValue
	-- Set by user to override the kitchen counter outlet.
	KitchenCounterOutletOverride :: Override PowerSetting -> SensedValue
	-- Set by the user to enable the removable drives.
	RemovableDrivesOverride :: Override PowerSetting -> SensedValue
	-- Set by the user to control the spring pump.
	SpringPumpOverride :: Override PowerSetting -> SensedValue
	SpringPumpRunCycle :: RunCycle -> SensedValue 
	deriving (Generic, Show, Eq)

isOverride :: SensedValue -> Bool
isOverride (CcLoadOverride _) = True
isOverride (FridgeOverride _) = True
isOverride (InverterOverride _) = True
isOverride (KitchenCounterOutletOverride _) = True
isOverride (RemovableDrivesOverride _) = True
isOverride (SpringPumpOverride _) = True
isOverride _ = False

sensorFailed :: SensedValue -> Bool
sensorFailed (CcInputVolts Nothing) = True
sensorFailed (CcInputAmps Nothing) = True
sensorFailed (CcInputWatts Nothing) = True
sensorFailed (CcOutputVolts Nothing) = True
sensorFailed (CcOutputAmps Nothing) = True
sensorFailed (CcTemperature Nothing) = True
sensorFailed (CcBatteryPercent Nothing) = True
sensorFailed (CcBatteryAmps Nothing) = True
sensorFailed (CcMaxInputVoltsToday Nothing) = True
sensorFailed (CcMaxBatteryVoltsToday Nothing) = True
sensorFailed (CcMinBatteryVoltsToday Nothing) = True
sensorFailed (CcKWHGeneratedToday Nothing) = True
sensorFailed (CcKWHGeneratedTotal Nothing) = True
sensorFailed (CcStatusCode Nothing) = True
sensorFailed (BatteryTemperature Nothing) = True
sensorFailed (PorchTemperature Nothing) = True
sensorFailed (InverterTemperature Nothing) = True
sensorFailed (SlabTemperature Nothing) = True
sensorFailed (HallTemperature Nothing) = True
sensorFailed (HallHumidity Nothing) = True
sensorFailed (FridgeTemperature Nothing) = True
sensorFailed (FridgeAuxTemperature Nothing) = True
-- spare probe is not always connected
sensorFailed (SpareProbeTemperature Nothing) = False
-- forecast download will faill when offline, not counted as a sensor failure
sensorFailed (ForecastHumidity Nothing) = False
sensorFailed (ForecastCloudCover Nothing) = False
sensorFailed (ForecastNearestStorm Nothing) = False
sensorFailed (ForecastPrecipRate Nothing) = False
sensorFailed (TrimetricBatteryPercent Nothing) = True
sensorFailed (TrimetricBatteryVolts Nothing) = True
sensorFailed (TrimetricBatteryWatts Nothing) = True
sensorFailed (TrimetricCCStatusCode Nothing) = True
sensorFailed _ = False

class DefSensedValue a where
	defSensedValue :: a

instance DefSensedValue (Maybe a) where
	defSensedValue = Nothing

instance DefSensedValue [a] where
	defSensedValue = []

instance DefSensedValue Bool where
	defSensedValue = False

instance DefSensedValue Integer where
	defSensedValue = 0

instance DefSensedValue (Override a) where
	defSensedValue = DisableOverride

instance DefSensedValue PowerSetting where
	defSensedValue = PowerSetting False

instance (DefSensedValue a, DefSensedValue b) => DefSensedValue (a, b) where
	defSensedValue = (defSensedValue, defSensedValue)

instance DefSensedValue Hours where
	defSensedValue = Hours 0

instance DefSensedValue Minutes where
	defSensedValue = Minutes 0

newtype KeySensedValue = KeySensedValue String
	deriving (Eq, Ord)

-- | A key for a SensedValue constructor, suitable for insertion in a map.
keySensedValue :: DefSensedValue a => (a -> SensedValue) -> KeySensedValue
keySensedValue c = keySensedValue' (c defSensedValue)

keySensedValue' :: SensedValue -> KeySensedValue
keySensedValue' = KeySensedValue . takeWhile (/= ' ') . show

-- | Format as a plain string with no units; used for populating rrd files.
formatSensedValue :: SensedValue -> Maybe String
formatSensedValue (CcInputVolts d) = formatDataUnit <$> d
formatSensedValue (CcInputAmps d) = formatDataUnit <$> d
formatSensedValue (CcInputWatts d) = formatDataUnit <$> d
formatSensedValue (CcOutputVolts d) = formatDataUnit <$> d
formatSensedValue (CcOutputAmps d) = formatDataUnit <$> d
formatSensedValue (CcTemperature d) = formatDataUnit <$> d
formatSensedValue (CcBatteryPercent d) = formatDataUnit <$> d
formatSensedValue (CcBatteryAmps d) = formatDataUnit <$> d
formatSensedValue (CcMaxInputVoltsToday d) = formatDataUnit <$> d
formatSensedValue (CcMaxBatteryVoltsToday d) = formatDataUnit <$> d
formatSensedValue (CcMinBatteryVoltsToday d) = formatDataUnit <$> d
formatSensedValue (CcKWHGeneratedToday d) = formatDataUnit <$> d
formatSensedValue (CcKWHGeneratedTotal d) = formatDataUnit <$> d
formatSensedValue (CcStatusCode d) = formatDataUnit <$> d
formatSensedValue (BatteryTemperature d) = formatDataUnit <$> d
formatSensedValue (PorchTemperature d) = formatDataUnit <$> d
formatSensedValue (InverterTemperature d) = formatDataUnit <$> d
formatSensedValue (SlabTemperature d) = formatDataUnit <$> d
formatSensedValue (HallTemperature d) = formatDataUnit <$> d
formatSensedValue (HallHumidity d) = formatDataUnit <$> d
formatSensedValue (ForecastHumidity d) = formatDataUnit <$> d
formatSensedValue (ForecastCloudCover d) = formatDataUnit <$> d
formatSensedValue (ForecastNearestStorm _) = Nothing
formatSensedValue (ForecastPrecipRate d) = formatDataUnit <$> d
formatSensedValue (FridgeTemperature d) = formatDataUnit <$> d
formatSensedValue (FridgeAuxTemperature d) = formatDataUnit <$> d
formatSensedValue (SpareProbeTemperature d) = formatDataUnit <$> d
formatSensedValue (DhcpClients _) = Nothing
formatSensedValue (TrimetricBatteryPercent d) = formatDataUnit <$> d
formatSensedValue (TrimetricBatteryVolts d) = formatDataUnit <$> d
formatSensedValue (TrimetricBatteryWatts d) = formatDataUnit <$> d
formatSensedValue (TrimetricCCStatusCode d) = formatDataUnit <$> d
formatSensedValue (AutomationOverallStatus _) = Nothing
formatSensedValue (AutomationFridgeRuntimeToday (d, _)) =
	Just $ formatDataUnit d
formatSensedValue (AutomationFridgeRunDuration d) = Just $ formatDataUnit d
formatSensedValue (CcLoadControlWorking _) = Nothing
formatSensedValue (CcLoadSetTo _) = Nothing
formatSensedValue (FridgeRelaySetTo _) = Nothing
formatSensedValue (KitchenCounterOutletRelaySetTo _) = Nothing
formatSensedValue (RemovableDrivesRelaySetTo _) = Nothing
formatSensedValue (UsbHubsRelaySetTo _) = Nothing
formatSensedValue (CcLoadOverride _) = Nothing
formatSensedValue (FridgeOverride _) = Nothing
formatSensedValue (SpringPumpOverride _) = Nothing
formatSensedValue (SpringPumpRunCycle _) = Nothing
formatSensedValue (InverterOverride _) = Nothing
formatSensedValue (KitchenCounterOutletOverride _) = Nothing
formatSensedValue (RemovableDrivesOverride _) = Nothing
formatSensedValue (SensorFailures d) = Just $ show d
	
formatAsHours :: NominalDiffTime -> String
formatAsHours secs = showDoublePrecision 2
	(fromRational (toRational secs) / 60 / 60)

instance ToJSON SensedValue
instance FromJSON SensedValue

data Override a
	= OverrideSeconds Int a
	| DisableOverride
	deriving (Generic, Show, Eq, Ord, Functor)

instance ToJSON a => ToJSON (Override a)
instance FromJSON a => FromJSON (Override a)

applyOverride :: (o -> a) -> Override o -> a -> a
applyOverride conv (OverrideSeconds _ a) _ = conv a
applyOverride _conv DisableOverride a = a

data Overridable v = Overridden v | SetTo v | NotKnown
	deriving (Eq, Show, Generic)

instance ToJSON v => ToJSON (Overridable v)
instance FromJSON v => FromJSON (Overridable v)

mkOverridable :: Override a -> Maybe a -> Overridable a
mkOverridable (OverrideSeconds _ override) _ = Overridden override
mkOverridable DisableOverride (Just a) = SetTo a
mkOverridable DisableOverride Nothing = NotKnown

data Status
	= LowPower
	| Sunny
	| InverterStatus (Overridable PowerSetting)
	| FridgeStatus (Overridable PowerSetting)
	| FridgeThoughts String
	| KitchenCounterOutletStatus PowerSetting
	| RemovableDrivesStatus PowerSetting
	| SpringPumpStatus PowerSetting
	deriving (Eq, Show, Generic)

instance ToJSON Status
instance FromJSON Status

data RunCycle = OnOffRunCycle
	{ onMinutes :: Int
	, offMinutes :: Int
	} deriving (Eq, Show, Generic)

instance ToJSON RunCycle
instance FromJSON RunCycle
