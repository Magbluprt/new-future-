{-# LANGUAGE LambdaCase, BangPatterns #-}

-- | Automation of my house, using FRP.

module Automation where

import Automation.Types
import Automation.Utility
import Automation.Solar
import Automation.Fridge
import Automation.KitchenCounterOutlet
import DataUnits
import DhcpClient
import Sensors

import Reactive.Banana
import Reactive.Banana.Automation
import Data.Functor.Compose
import Data.Time.Clock.POSIX
import Data.Maybe
import Data.List

homeAutomation :: Automation (Sensors t) Actuators ()
homeAutomation = do
	fridgethoughts <- fridgeThoughts
	controlInverter fridgethoughts
	controlFridgeRelay fridgethoughts
	controlSpringPump
	controlRemovableDrives
	controlKitchenCounterOutlet
	overallStatus fridgethoughts
	collectStats fridgethoughts
	debug fridgethoughts

controlFridgeRelay :: FridgeThoughts -> Automation (Sensors t) Actuators ()
controlFridgeRelay t = do
	b <- fridgeBehavior t
	actuateBehaviorMaybe b FridgeRelay

-- | Keep the removable drives off unless overridden on.
--
-- Even when overridden on, turn them off when the
-- kitchen counter outlet is in use. (But, there might be a couple
-- minutes while they're still on, since it takes a while to unmount them.)
removableDrivesBehavior :: Automation (Sensors t) Actuators (Behavior PowerChange)
removableDrivesBehavior = offWhenKitchenCounterOutletOn id $
	applyOverrideM (pure PowerOff) removableDrivesOverride id

-- | To turn on the removable drives, need to enable the relay that turns
-- on the additional USB hubs, and the relay that powers on the drives.
-- Systemd will automatically turn on USB ports on those hubs on demand,
-- keeping the rest of the removable drives spun down.
--
-- Rather than immediately powering down all hub ports, trigger the
-- automounter to mount all removable drives. If a drive is not used after
-- a few minutes, the automounter will then unmount it and systemd will
-- power it down.
controlRemovableDrives :: Automation (Sensors t) Actuators ()
controlRemovableDrives = do
	b <- removableDrivesBehavior
	actuateBehavior b go
  where
	go PowerOn = ActuatorSequence
		[ InSequence $ UsbHubsRelay PowerOn
		, InSequence $ RemovableDrivesRelay PowerOn
		-- Wait for the drives to become available.
		, PauseFor 120
		, InSequence AutoMountRemovableDrives
		]
	go PowerOff = ActuatorSequence
		[ InSequence UnmountRemovableDrives
		-- Pause briefly to let the drives spin down cleanly
		-- without data loss.
		, PauseFor 120
		, InSequence $ RemovableDrivesRelay PowerOff
		, InSequence $ UsbHubsRelay PowerOff
		]

-- | The spring pump can run any time.
--
-- It can be overridden off. Its run cycle is otherwise controlled by the
-- springPumpRunCycle.
springPumpBehavior :: Automation (Sensors t) Actuators (Behavior PowerChange)
springPumpBehavior = do
	b <- getCompose $ go 
		<$> Compose (clockSignalBehavior currentTime)
		<*> Compose (automationStepper defaultruncycle
			=<< getEventFrom springPumpRunCycle)
	applyOverrideM b springPumpOverride id
  where
	go (Just (ClockSignal clock)) runcycle = calcRunCycle runcycle clock
	go Nothing _ = PowerOff

	defaultruncycle = OnOffRunCycle
		{ onMinutes = 1
		, offMinutes = 0
		}

calcRunCycle :: RunCycle -> POSIXTime -> PowerChange
calcRunCycle runcycle@(OnOffRunCycle {}) clock
	| seglen == 0 = PowerOn
	| minnum `mod` seglen < onMinutes runcycle = PowerOn
	| otherwise = PowerOff
  where
	seglen = onMinutes runcycle + offMinutes runcycle
	minnum = floor (clock / 60)

controlSpringPump :: Automation (Sensors t) Actuators ()
controlSpringPump = do
	b <- springPumpBehavior
	actuateBehavior b SpringPumpFloatSwitch

controlInverter :: FridgeThoughts -> Automation (Sensors t) Actuators ()
controlInverter fridgethoughts = do
	b <- inverterBehavior fridgethoughts
	actuateBehaviorMaybe b InverterPower

-- | Overall behavior of the inverter.
--
-- Limit rate that InverterPower actuator is used to once per 10 seconds, to
-- prevent wear and tear, and because a fast power cycle can cause the
-- satellite modem to get into a strange state.
--
-- However, overrides to the inverter power take effect immediately.
inverterBehavior :: FridgeThoughts -> Automation (Sensors t) Actuators (Behavior (Maybe PowerChange))
inverterBehavior fridgethoughts =
	overallBehavior (inverterWanted fridgethoughts) (Just (DelaySeconds 10)) inverterOverride id

-- | Active wifi users.
--
-- This uses a whitelist of devices that are not on all the time or
-- may be left on accidentially, since it keeps the satellite internet
-- up for these.
wifiUsers :: Automation (Sensors t) Actuators (Behavior (Maybe [DhcpClient]))
wifiUsers = do
	clock <- clockSignalBehavior currentTime
	dhcpclients <- automationStepper Nothing
		=<< (fmap Just <$> getEventFrom dhcpClients)
	return $ calc <$> clock <*> dhcpclients
  where
	calc (Just (ClockSignal clock)) (Just dhcpclients) = 
		Just $ filter leaseValid $ map (addgraceperiod clock) $
			filter whitelisted dhcpclients
	calc _ _ = Nothing
	
	-- There's a 20 minute grace period, during which an expired
	-- dhcp lease is still considered a wifi user.
	graceperiod = 60 * 20
	addgraceperiod clock = updateLeaseValid (clock - graceperiod)

	whitelisted c
		| "darkstar" `isPrefixOf` cn = True
		| "LAPTOP-TVDSTQBM" `isPrefixOf` cn = True
		| otherwise = False
	  where
		cn = clientName c

-- | Number of active wifi users.
numWifiUsers :: Automation (Sensors t) Actuators (Behavior Int)
numWifiUsers = getCompose $ calc <$> Compose wifiUsers
  where
	calc (Just l) = length l
	-- When wifi users are not known, assume there's at least one.
	-- This normally only happens breifly after startup.
	calc Nothing = 1

-- | Do we want to run the inverter?
--
-- Most importantly: When power is low turn off the inverter.
--
-- The satellite modem is powered by the inverter, as is the fridge,
-- and the kitchen counter outlet. If anyone is using the the house's
-- wifi, turn on the inverter (unless power is low) so they can get online.
--
-- When nobody is using wifi, the inverter can be turned off, but only
-- when the fridge does not want to run, and the kitchen counter outlet is
-- switched off.
--
-- On a sunny day, run the inverter speculatively, since the excess power
-- would otherwise bounce off the roof.
inverterWanted :: FridgeThoughts -> Automation (Sensors t) Actuators (Behavior (Maybe PowerChange))
inverterWanted fridgethoughts = getCompose $ react
	<$> Compose lowpowerMode
	<*> Compose numWifiUsers
	<*> Compose isSunnyDay
	<*> Compose (pure (fridgeWanted fridgethoughts))
	<*> Compose kitchenCounterOutletBehavior
  where
	react lowpower wifiusers sunnyday fridgewanted kitchencounterwanted
		| lowpower = Just PowerOff
		| wifiusers > 0 = Just PowerOn
		| sunnyday = Just PowerOn
		| otherwise = case fridgewanted of
			Just PowerOn -> Just PowerOn
			_ -> Just kitchencounterwanted

debug :: FridgeThoughts -> Automation (Sensors t) Actuators ()
debug fridgethoughts = do
	voltage <- sensedBehavior ccBatteryVoltage
	actuateBehavior voltage $ Debug "cc battery voltage" . show
	watts <- sensedBehavior inputWatts
	actuateBehavior watts $ Debug "input watts" . show

	fridgetemp <- sensedBehavior fridgeTemperature
	actuateBehavior fridgetemp $ Debug "fridge temperature" . show
	ofridgethoughts <- occasionalFridgeThoughts fridgethoughts
	actuateBehavior ofridgethoughts $ Debug "fridge thoughts" . show
	fridgeruntimetoday <- fridgeRuntimeToday fridgethoughts
	actuateBehavior fridgeruntimetoday $ Debug "fridge runtime today" . show . fst
	fridgerunduration <- fridgeRunDuration fridgethoughts
	actuateBehavior fridgerunduration $ Debug "fridge run duration" . show
	
	lp <- lowpowerMode
	actuateBehavior lp $ Debug "low power mode" . show
	solarestimate <- solarEstimate
	actuateBehavior solarestimate $ Debug "solar estimate" . show
	numwifiusers <- numWifiUsers
	actuateBehavior numwifiusers $ Debug "num wifi users" . show
	wifiusers <- wifiUsers
	actuateBehavior wifiusers $ Debug "wifi users" . show 
		. fmap (map clientName)

overallStatus :: FridgeThoughts -> Automation (Sensors t) Actuators ()
overallStatus fridgethoughts = do
	st <- getCompose $ go
		<$> Compose lowpowerMode
		<*> Compose isSunnyDay
		<*> Compose (powerSettingBehavior' =<< inverterBehavior fridgethoughts)
		<*> Compose (powerSettingBehavior' =<< fridgeBehavior fridgethoughts)
		<*> Compose (occasionalFridgeThoughts fridgethoughts)
		<*> Compose (override inverterOverride)
		<*> Compose (override fridgeOverride)
		<*> Compose kitchenCounterOutletBehavior
		<*> Compose removableDrivesBehavior
		<*> Compose springPumpBehavior
	actuateBehavior st OverallStatus
  where
	override f = getEventFrom f
		>>= automationStepper DisableOverride
		>>= return . fmap (fmap powerChangeToPowerSetting)
	go lowpower sunnyday inverter fridge ofridgethoughts inverteroverride fridgeoverride kitchenoutlet drives springpump =
		catMaybes
			[ case sunnyday of
				True -> Just Sunny
				False -> Nothing
			, Just $ InverterStatus $ mkOverridable
				inverteroverride inverter
			, Just $ FridgeStatus $ mkOverridable
				fridgeoverride fridge
			, case lowpower of
				True -> Just LowPower
				False -> Nothing
			, Just $ Sensors.FridgeThoughts $ show ofridgethoughts
			, Just $ KitchenCounterOutletStatus $ powerChangeToPowerSetting kitchenoutlet
			, Just $ RemovableDrivesStatus $ powerChangeToPowerSetting drives
			, Just $ SpringPumpStatus $ powerChangeToPowerSetting springpump
			]

-- | Collection of various stats about the automation.
collectStats :: FridgeThoughts -> Automation (Sensors t) Actuators ()
collectStats fridgethoughts = do
	flip actuateBehavior FridgeRuntimeToday =<< fridgeRuntimeToday fridgethoughts
	flip actuateBehavior FridgeRunDuration =<< fridgeRunDuration fridgethoughts 
