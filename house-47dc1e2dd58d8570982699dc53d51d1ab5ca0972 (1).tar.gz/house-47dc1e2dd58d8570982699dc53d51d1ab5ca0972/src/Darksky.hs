{-# LANGUAGE DeriveGeneric, OverloadedStrings #-}

module Darksky where

import Network.HTTP.Client
import Control.Exception
import Data.Aeson
import GHC.Generics
import qualified Data.Text as T

import DataUnits

-- | Contains API key, so can't include in this project.
urlFile :: FilePath
urlFile = "/etc/darksky-forecast-url"

getRequest :: IO Request
getRequest = parseRequest =<< takeWhile (/= '\n') <$> readFile urlFile

downloadForecast :: Manager -> Request -> IO (Either String Forecast)
downloadForecast manager request = do
	v <- tryHttpException $ httpLbs request manager
	return $ case v of
		Left e -> Left $ show e
		Right response -> eitherDecode $ responseBody response

tryHttpException :: IO a -> IO (Either HttpException a)
tryHttpException = try 

-- | Not complete; only the fields I need so far..
data Forecast = Forecast
	{ currently :: DataPoint
	, minutely :: Maybe Block
	, hourly :: Maybe Block
	, daily :: Maybe Block
	}
	deriving (Generic, Show)

instance FromJSON Forecast

data DataPoint = DataPoint
	{ humidity :: Maybe Double
	, dewPoint :: Maybe Double
	, cloudCover :: Maybe Double
	, nearestStormDistance :: Maybe Double
	, nearestStormBearing :: Maybe Double
	, precipIntensity :: Maybe Double
	}
	deriving (Generic, Show)

instance FromJSON DataPoint

data Block = Block
	{ blockSummary :: T.Text
	, blockData :: [DataPoint]
	} deriving (Show)

instance FromJSON Block where
	parseJSON (Object x) = Block
		<$> x .: "summary"
		<*> x .: "data"
	parseJSON _ = fail "Expected an Object"

currentRelativeHumidity :: Forecast -> Maybe RelativeHumidity
currentRelativeHumidity f = RelativeHumidity . Percentage . (* 100) <$>
	humidity (currently f)

currentCloudCover :: Forecast -> Maybe Percentage
currentCloudCover f = Percentage . (* 100) <$> cloudCover (currently f)

currentPrecipRate :: Forecast -> Maybe InchesPerHour
currentPrecipRate f = InchesPerHour <$> (precipIntensity (currently f))

data StormLocation = NearbyStorm Miles AbsoluteBearing | OverheadStorm
	deriving (Generic, Show, Eq)

instance ToJSON StormLocation
instance FromJSON StormLocation

currentNearestStorm :: Forecast -> Maybe StormLocation
currentNearestStorm f = do
	distance <- Miles <$> nearestStormDistance (currently f)
	if distance > Miles 0
		then do
			-- Only care about storms that may affect us
			-- in the next 30 minutes, not ones that will miss
			-- us or are moving away after hitting us.
			soon <- take 30 . blockData <$> minutely f
			if any hasprecip soon
				then do
					bearing <- AbsoluteBearing <$> nearestStormBearing (currently f)
					return $ NearbyStorm distance bearing
				else Nothing
		else do
			-- The storm distance is 0 both when there is
			-- a storm overhead, and when there's no storm.
			if hasprecip (currently f)
				then return OverheadStorm
				else Nothing
  where
	hasprecip d = case precipIntensity d of
		Nothing -> False
		Just p -> p > 0
