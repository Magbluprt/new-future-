module Darksky.Poller where

import Network.HTTP.Client.TLS

import Darksky
import Sensors
import WebServers (AddSensedValue)
import Utility.ThreadScheduler

-- | Download forcast every 2 minutes, which is 360 call per day.
-- The darksky api is limited to 1000 free calls per day.
--
-- The complete forecast is 30 kb, so this downloads 10 mb per day.
pollForecast :: AddSensedValue -> IO ()
pollForecast sensed = do
	m <- newTlsManager
	r <- getRequest
	go m r
  where
	go m r = do
		f <- either (const Nothing) Just <$> downloadForecast m r
		sensed $ ForecastHumidity $
			currentRelativeHumidity =<< f
		sensed $ ForecastCloudCover $
			currentCloudCover =<< f
		sensed $ ForecastNearestStorm $
			currentNearestStorm =<< f
		sensed $ ForecastPrecipRate $
			currentPrecipRate =<< f
		threadDelaySeconds (Seconds 120)
		go m r
