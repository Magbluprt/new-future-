module Automation.Types where

import DataUnits
import Sensors
import DhcpClient
import qualified Epsolar

import Reactive.Banana.Automation
import Data.Time.Clock
import Data.Time.Clock.POSIX
import Data.Time.Calendar

data Sensors t = Sensors
	{ ccBatteryVoltage :: EventSource (Sensed Volts) t
	, trimetricBatteryVoltage :: EventSource (Sensed Volts) t
	, trimetricBatteryPercent :: EventSource (Sensed Percentage) t
	, trimetricBatteryWatts :: EventSource (Sensed Watts) t
	, ccBatteryPercent :: EventSource (Sensed Percentage) t
	, inputWatts :: EventSource (Sensed Watts) t
	, kwhGeneratedToday :: EventSource (Sensed KWH) t
	, ccChargingStatus :: EventSource (Sensed Epsolar.ChargingStatus) t
	, ccLoadSetTo :: EventSource (Sensed PowerSetting) t
	, fridgeRelaySetTo :: EventSource (Sensed PowerSetting) t
	, porchTemperature :: EventSource (Sensed Temperature) t
	, fridgeTemperature :: EventSource (Sensed Temperature) t
	, dhcpClients :: EventSource [DhcpClient] t
	, kitchenCounterSwitchSetTo :: EventSource (Sensed (Bool, POSIXTime)) t
	, minuteHand :: EventSource (ClockSignal Int) t
	, secondHand :: EventSource (ClockSignal Int) t
	, currentTime :: EventSource (ClockSignal POSIXTime) t
	, fridgeOverride :: EventSource (Override PowerChange) t
	, inverterOverride :: EventSource (Override PowerChange) t
	, ccLoadOverride :: EventSource (Override PowerChange) t
	, springPumpOverride :: EventSource (Override PowerChange) t
	, springPumpRunCycle :: EventSource RunCycle t
	, removableDrivesOverride :: EventSource (Override PowerChange) t
	, kitchenCounterOutletOverride :: EventSource (Override PowerChange) t
	, lastKnownFridgeRuntimeToday :: EventSource (Sensed (Hours, Maybe Day)) t
	}

mkSensors :: IO t -> IO (Sensors t)
mkSensors mkt = Sensors
	<$> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
	<*> yada
  where
	yada = newEventSource =<< mkt

testSensors :: IO (Sensors ())
testSensors = mkSensors (return ())

data Actuators
	= InverterPower PowerChange
	| CcLoad PowerChange
	| FridgeRelay PowerChange
	| SpringPumpFloatSwitch PowerChange
	| KitchenCounterOutletRelay PowerChange
	| RemovableDrivesRelay PowerChange
	| UsbHubsRelay PowerChange
	| AutoMountRemovableDrives
	| UnmountRemovableDrives
	| Debug String String
	| OverallStatus [Status]
	| FridgeRuntimeToday (Hours, Maybe Day)
	| FridgeRunDuration Minutes
	| ActuatorSequence [ActuatorSequence]

data ActuatorSequence
	= InSequence Actuators
	| PauseFor NominalDiffTime

instance Show Actuators where
	show (InverterPower p) = "InverterPower: " ++ show p
	show (CcLoad p) = "CcLoad: " ++ show p
	show (FridgeRelay p) = "FridgeRelay: " ++ show p
	show (SpringPumpFloatSwitch p) = "SpringPumpFloatSwitch: " ++ show p
	show (KitchenCounterOutletRelay p) = "KitchenCounterOutletRelay: " ++ show p
	show (RemovableDrivesRelay p) = "RemovableDrivesRelay: " ++ show p
	show (UsbHubsRelay p) = "UsbHubsRelay: " ++ show p
	show AutoMountRemovableDrives = "AutoMountRemovableDrives"
	show UnmountRemovableDrives = "UnmountRemovableDrives"
	show (Debug s v) = "Debug " ++ s ++ ": " ++ v
	show (OverallStatus l) = "OverallStatus: " ++ show l
	show (FridgeRuntimeToday v) = "FridgeRuntimeToday: " ++ show v
	show (FridgeRunDuration v) = "FridgeRunDuration: " ++ show v
	show (ActuatorSequence l) = show l

instance Show ActuatorSequence where
	show (InSequence a) = show a
	show (PauseFor n) = "PauseFor " ++ show n
