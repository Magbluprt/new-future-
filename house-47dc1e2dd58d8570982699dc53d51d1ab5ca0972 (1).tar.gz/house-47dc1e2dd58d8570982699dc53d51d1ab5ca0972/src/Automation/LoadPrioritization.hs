module Automation.LoadPrioritization where

import Automation.Types
import Automation.Utility
import DataUnits

import Reactive.Banana
import Reactive.Banana.Automation
import Data.Functor.Compose

data Load = Load
	{ loadPowerChange :: Maybe PowerChange
	, loadPrevPowerSetting :: PowerSetting
	, loadActuators :: PowerChange -> Actuators
	}

mkLoad :: (PowerChange -> Actuators) -> Behavior (Maybe PowerChange) -> Automation sensors actuators (Behavior Load)
mkLoad c b = getCompose $ Load
	<$> Compose (pure b)
	<*> Compose (powerSettingBehavior (PowerSetting False) b)
	<*> Compose (pure (pure c))

-- This is a bit limited by there being no equivilant of powerSettingBehavior
-- for UntilTime PowerChange.
--
-- So, 0 had to be used in the case where the load had earlier tried to
-- turn on but been blocked by a higher priority load. The load will turn
-- on, but with an invalid UntilTime (in the past). That might cause
-- unwanted effects with things that look at that value.
mkLoadUntilTime
	:: (UntilTime PowerChange -> Actuators)
	-> Behavior (Maybe (UntilTime PowerChange))
	-> Automation sensors actuators (Behavior Load)
mkLoadUntilTime c b = do
	let pb = fmap untilValue <$> b
	getCompose $ Load
		<$> Compose (pure pb)
		<*> Compose (powerSettingBehavior (PowerSetting False) pb)
		<*> Compose (pure (mk <$> b))
  where
	mk ut pc = c (UntilTime (maybe 0 untilTime ut) pc)

-- Run only one load from the list at a time, which is in order from
-- highest priority to lowest.
prioritizeLoads :: [Load] -> Actuators 
prioritizeLoads = go []
  where
	go s [] = ActuatorSequence (reverse s)
	go s ((Load (Just PowerOff) _ c):ls) =
		go (InSequence (c PowerOff):s) ls
	go s ((Load (Just PowerOn) _ c):ls) = offthenon
		(s ++ map InSequence (alloff ls))
		(c PowerOn)
	-- When the load was already on, and there's no change, 
	-- nothing needs to be done.
	go _ ((Load Nothing (PowerSetting True) _):_) = ActuatorSequence []
	-- When the load was off, and there's no change, no need to turn it
	-- off again when turning on any other load.
	go s ((Load Nothing (PowerSetting False) _):ls) = go s ls

	alloff [] = []
	alloff (Load _ _ c:rest) = c PowerOff : alloff rest

	offthenon off on
		| null off = on
		-- Turn everything else off first, and pause briefly
		-- for relays to switch before turning the load on.
		| otherwise = ActuatorSequence $ concat
			[ off
			, [PauseFor 1, InSequence on]
			]	
