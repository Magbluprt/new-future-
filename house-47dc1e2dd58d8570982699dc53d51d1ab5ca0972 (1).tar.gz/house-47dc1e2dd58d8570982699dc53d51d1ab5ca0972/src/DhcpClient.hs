{-# LANGUAGE DeriveGeneric, LambdaCase #-}

module DhcpClient (
	IpAddr(..),
	DhcpClient(..),
	readLeases,
	notifyDhcpClientChanges,
	nmapDhcpClientChanges,
	updateLeaseValid,
) where

import System.IO
import System.INotify
import System.Directory
import System.Process
import Control.Concurrent
import Control.Concurrent.Async
import Control.Concurrent.STM
import qualified Data.Map.Strict as M
import Data.Time.Clock.POSIX
import Data.Maybe
import Data.Aeson
import Data.String
import Data.List
import Control.Monad
import Text.Read
import GHC.Generics
import Control.Applicative
import Prelude

import Utility.ThreadScheduler

newtype IpAddr = IpAddr String
	deriving (Show, Generic, Ord, Eq)

instance ToJSON IpAddr
instance FromJSON IpAddr

data DhcpClient = DhcpClient
	{ leaseExpires :: POSIXTime
	, leaseValid :: Bool
	, ipAddr :: IpAddr
	, clientName :: String
	}
	deriving (Show, Eq, Generic)

instance ToJSON DhcpClient
instance FromJSON DhcpClient

leaseFile :: FilePath
leaseFile = "/var/lib/misc/dnsmasq.leases"

readLeases :: IO [DhcpClient]
readLeases = do
	now <- getPOSIXTime
	mapMaybe (parse now) . lines <$> readFile leaseFile
  where
	parse now l = case words l of
		(ts:_mac:ip:name:_) -> do
			t <- fromIntegral <$> (readMaybe ts :: Maybe Integer)
			return (DhcpClient t (t > now) (IpAddr ip) name)
		_ -> Nothing

-- Wait for the lease file to be created; it may not exist yet on initial
-- boot of a newly installed system.
waitLeaseFile :: IO ()
waitLeaseFile = go =<< doesFileExist leaseFile
  where
	go True = return ()
	go False = do
		threadDelay 1000000
		waitLeaseFile

updateLeaseValid :: POSIXTime -> DhcpClient -> DhcpClient
updateLeaseValid now dc = dc { leaseValid = leaseExpires dc > now }

type LeaseMap = M.Map IpAddr DhcpClient

makeLeaseMap :: [DhcpClient] -> LeaseMap
makeLeaseMap = M.fromList . map (\dc -> (ipAddr dc, dc))

updateLeaseMap :: DhcpClient -> LeaseMap -> LeaseMap
updateLeaseMap dc = M.insert (ipAddr dc) dc

-- | Get list of dhcp clients by inotify on dnsmasq's leases file.
--
-- The callback always gets a list of all leases at the time it's called.
--
-- dnsmasq rewinds the file and rewrites it, so it's not updated on
-- disk atomically. So, this keeps a map of leases it has seen,
-- and only triggers the callback when a lease expires or is granted.
notifyDhcpClientChanges :: ([DhcpClient] -> IO ()) -> IO ()
notifyDhcpClientChanges a = do
	i <- initINotify
	waitLeaseFile
	initialleases <- makeLeaseMap <$> readLeases
	-- Send starting value to the callback.
	a (M.elems initialleases)
	tv <- newTVarIO initialleases
	wv <- newEmptyTMVarIO
	void $ addWatch i [Modify] (fromString leaseFile) $ \_ -> do
		-- Wait for the non-atomic write to settle.
		-- If there are several writes, we may read while
		-- another write is in progress and get incomplete data,
		-- but the subsequent read will correct that.
		threadDelay 2000000
		mapM_ (atomically . modifyTVar tv . updateLeaseMap) =<< readLeases
		atomically $ void $ tryPutTMVar wv ()
	notifier initialleases tv wv
  where
	-- Wait for a signal on the wv, or sleep until the next lease is
	-- due to expire. Then check for expired leases, and new leases,
	-- send signals about them, and repeat.
	notifier oldm tv wv = do
		now <- getPOSIXTime
		newm <- atomically $ do
			m <- readTVar tv
			let newm = M.map (updateLeaseValid now) m
			writeTVar tv newm
			return newm
		if newm /= oldm
			then a (M.elems newm)
			else return ()
		race_ (atomically $ takeTMVar wv) (waitnextexpire tv)
		notifier newm tv wv
	
	waitnextexpire tv = do
		now <- getPOSIXTime
		waitseconds <- atomically $ minimum 
			. (60*60 :)
			. filter (> 0)
			. map (\t -> ceiling (t - now))
			. M.elems
			. M.map leaseExpires
			<$> readTVar tv
		threadDelaySeconds (Seconds waitseconds)

-- | Dummy up a list of dhcp clients by using nmap to scan the network.
--
-- The callback always gets a list of all leases at the time it's called.
--
-- Clients that were seen within the past ten minutes are included even if
-- they are not up at the time of the scan.
nmapDhcpClientChanges :: ([DhcpClient] -> IO ()) -> IO ()
nmapDhcpClientChanges a = go M.empty
  where
	go m = do
		threadDelaySeconds (Seconds 60)
		now <- getPOSIXTime
		m' <- foldr updateLeaseMap m <$> nmapScan (now + 10*60)
		let m'' = M.map (updateLeaseValid now) m'
		a (M.elems m'')
		go m''

nmapScan :: POSIXTime -> IO [DhcpClient]
nmapScan expiretime = do
	readProcessWithExitCode "nmap" ["-sn", "192.168.1.2-254", "-oG", "-"] "" >>= \case
                (_exitcode, out, _err) -> 
			return (mapMaybe (parseNmapScanLine expiretime) (lines out))

parseNmapScanLine :: POSIXTime -> String -> Maybe DhcpClient
parseNmapScanLine expiretime s = case words s of
	("Host:":ipaddr:cn:"Status:":"Up":_) -> Just $ DhcpClient
		{ leaseExpires = expiretime
		, leaseValid = True
		, ipAddr = IpAddr ipaddr
		, clientName = filter (`notElem` "()") cn
		}
	_ -> Nothing
