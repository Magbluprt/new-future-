import Test.DocTest

main = doctest ["-isrc", "-fno-warn-tabs", "src/Automation.hs"]
