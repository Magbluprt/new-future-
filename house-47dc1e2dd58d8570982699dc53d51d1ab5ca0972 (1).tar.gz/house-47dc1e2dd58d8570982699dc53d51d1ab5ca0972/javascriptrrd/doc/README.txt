javascriptRRD
=============

javascriptRRD package contains a set of Javascript libraries
that can be used for reading RRD archives from any Web browser.
Mozilla, Internet Explorer and Safari havae been tested.

Being Javascript an interpreted language, no compilation is needed.
Just copy the files in the files located in the 
src/lib
directory into a Web accessible location and use them.

The 
src/examples/
directory contain example Web pages that you can use as a template
for writing your own Web Browser applications for accessing the
RRD archives on your Web server.

While the code itself tries to be self documenting, the 
doc/lib/
directory contains more detailed information about the libraries.

