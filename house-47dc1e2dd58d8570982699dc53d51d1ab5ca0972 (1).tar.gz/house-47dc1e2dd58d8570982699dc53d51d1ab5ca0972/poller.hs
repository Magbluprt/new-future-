{-# LANGUAGE FlexibleContexts, LambdaCase #-}

-- | Polls the charge controller and other sensors and sources for data,
-- and updates the rrd files and the json for the web page.
--
-- Runs a http server which streams sensed values to clients as they
-- become available. Some data can also be posted to the http server.

import System.IO
import System.Process
import System.Directory
import System.FilePath
import Data.List
import Data.Maybe
import Data.Char
import Control.Monad
import Control.Concurrent
import Control.Concurrent.Async
import Data.Time.Clock
import Control.Exception
import System.Timeout
import System.Exit
import System.Posix.Files
import Text.Read

import RRD
import Sensors
import WebServers
import DataUnits
import DhcpClient
import Utility.ThreadScheduler
import Epsolar
import Trimetric.Poller
import Darksky.Poller

data DataSource = DataSource RrdName (Maybe (String -> SensedValue)) DataSourceType Heartbeat
data DataSourceType = Gauge | Counter
newtype Heartbeat = HeartBeat Seconds

formatDataSource :: DataSource -> String
formatDataSource (DataSource name _ t (HeartBeat (Seconds h))) = intercalate ":"
	[ "DS"
	, name
	, formatDataSourceType t
	, show h
	, "U" -- unknown min
	, "U" -- unknown max
	]

formatDataSourceType :: DataSourceType -> String
formatDataSourceType Gauge = "GAUGE"
formatDataSourceType Counter = "COUNTER"

data DataSourceFrom
	= EpsolarStatusValue (Maybe EpsolarStatus -> SensedValue)
	| EpsolarExtStatusValue (Maybe EpsolarExtStatus -> SensedValue)
	| EpsolarOtherStatusValue (Maybe EpsolarOtherStatus -> SensedValue)
	| OneWireSensor String
	| SI7021 String
	| StoredSensedValue KeySensedValue SensedValue

dataSources :: FreqPair StepLen -> FreqPair [(DataSourceFrom, DataSource)]
dataSources steplen = FreqPair
	{ frequent =
		[ mkfe Gauge EpsolarStatusValue CcInputVolts epsolar_input_volts "input_volts"
		, mkfe Gauge EpsolarStatusValue CcOutputVolts epsolar_output_volts "output_volts"
		, mkfe Gauge EpsolarStatusValue CcInputWatts epsolar_input_watts "input_watts"
		, mkfa Gauge TrimetricBatteryPercent "battery_percent"
		, mkfe Gauge EpsolarStatusValue CcBatteryAmps epsolar_output_amps "battery_amps"
		, mkf Gauge (OneWireSensor "28-000009b76d38") "fridge_temp_celsius" FridgeTemperature 3
		, mkfa Gauge TrimetricBatteryWatts "trimetric_watts"
		, mkfa Gauge TrimetricBatteryVolts "trimetric_volts"
		]
	, infrequent =
		[ mkie Gauge EpsolarOtherStatusValue CcMaxInputVoltsToday epsolar_max_input_volts_today "max_input_volts"
		, mkie Gauge EpsolarOtherStatusValue CcMaxBatteryVoltsToday epsolar_max_battery_volts_today "max_battery_volts"
		, mkie Gauge EpsolarOtherStatusValue CcMinBatteryVoltsToday epsolar_min_battery_volts_today "min_battery_volts"
		, mkie Gauge EpsolarOtherStatusValue CcKWHGeneratedToday epsolar_kwh_generated_today "kwh_generated_today"
		, mkie Gauge EpsolarOtherStatusValue CcKWHGeneratedTotal epsolar_kwh_generated_total "kwh_generated_total"
		, mkie Gauge EpsolarExtStatusValue CcTemperature epsolar_inside_temp "cc_temp_celsius"
		, mkie Gauge EpsolarOtherStatusValue BatteryTemperature epsolar_battery_temp "batt_temp_celsius"
		, mki Gauge (OneWireSensor "28-0000098cd407") "porch_temp_celsius" PorchTemperature 3
		, mki Gauge (SI7021 "Temperature") "hall_temp_celsius" HallTemperature 3
		, mki Gauge (OneWireSensor "28-000009b76d38") "fridge_temp_celsius" FridgeTemperature 3
		, mkia Gauge AutomationFridgeRuntimeToday "fridge_hours_today"
		, mkia Gauge AutomationFridgeRunDuration "fridge_run_duration"
		, mki Gauge (OneWireSensor "28-0417007c85ff") "fridge_aux_temp" FridgeAuxTemperature 3
		, mki Gauge (OneWireSensor "28-00000a37ba58") "spare_probe_temp" SpareProbeTemperature 3
		, mkie Gauge EpsolarOtherStatusValue CcStatusCode epsolar_statuscode "cc_status_code"
		, mki Gauge (SI7021 "Relative Humidity") "hall_humidity" HallHumidity 1
		, mkia Gauge ForecastHumidity "forecast_humidity"
		, mki Gauge (OneWireSensor "28-00000a386f70") "inverter_temp" InverterTemperature 3
		, mki Gauge (OneWireSensor "28-03170068a7ff") "slab_temp" SlabTemperature 3
		, mkia Gauge SensorFailures "sensor_failures"
		, mkia Gauge TrimetricCCStatusCode "trimetric_cc_status"
		-- This is not accurate with battleborn lithium batteries,
		-- and could be removed, but the historical data might be
		-- useful still.
		, mkie Gauge EpsolarExtStatusValue CcBatteryPercent epsolar_battery_percent "cc_battery_percent"
		]
	}
  where
	mkf t dsf rrdname mkval p = mk (frequent steplen) t dsf rrdname (valparser mkval p)
	mki t dsf rrdname mkval p = mk (infrequent steplen) t dsf rrdname (valparser mkval p)
	mkfe t c u f rrdname = mk (frequent steplen) t dsf rrdname Nothing
	  where
		dsf = c $ \v -> u (f <$> v)
	mkie t c u f rrdname = mk (infrequent steplen) t dsf rrdname Nothing
	  where
		dsf = c $ \v -> u (f <$> v)
	mkfa t f rrdname = mk (frequent steplen) t dsf rrdname Nothing
	  where
		dsf = StoredSensedValue (keySensedValue f) (f defSensedValue)
	mkia t f rrdname = mk (infrequent steplen) t dsf rrdname Nothing
	  where
		dsf = StoredSensedValue (keySensedValue f) (f defSensedValue)
	mk (StepLen (Seconds steplen')) t dsf rrdname p =
		(dsf, DataSource rrdname p t hb)
	  where
		-- Allow missing one value before it goes unknown in the rrd.
		hb = HeartBeat (Seconds (steplen' * 2))
	valparser mkval p = Just $ mkval . parseDataUnit p

createRRD :: FilePath -> StepLen -> [(DataSourceFrom, DataSource)] -> [RRA] -> IO ()
createRRD f (StepLen (Seconds steplensecs)) ds rra = do
	createDirectoryIfMissing True (takeDirectory f)
	print ps
	callProcess "rrdtool" ps
  where
	ps = concat
		[ [ "create", f, "--step=" ++ show steplensecs ]
		, map (formatDataSource . snd) ds
		, map formatRRA rra
		]

updateRRD :: FilePath -> [(DataSource, SensedValue)] -> IO ()
updateRRD f vs
	| null vs' = return ()
	| otherwise = do
		(Nothing, Nothing, Nothing, p) <- createProcess $ proc "rrdupdate" ps
		r <- waitForProcess p
		case r of
			ExitFailure _ -> do
				hPutStrLn stderr $ "rrdupdate failed with params: " ++ show ps
				hFlush stderr
				return ()
			ExitSuccess -> return ()
  where
	ps = [ f, "--template", template, "N:" ++ vals ]
	template = intercalate ":" (map (rrdname . fst) vs')
	vals = intercalate ":" (map snd vs')
	vs' = catMaybes $ map elim vs
	elim (ds, sv) = case formatSensedValue sv of
		Nothing -> Nothing
		Just s -> Just (ds, s)
	rrdname (DataSource n _ _ _) = n

data QueryHandle = QueryHandle
	QSem
	EpsolarHandle
	(RegisterVectorFor EpsolarStatus)
	(RegisterVectorFor EpsolarSingleValue)
	(RegisterVectorFor EpsolarSingleValueWide)

mkQueryHandle :: IO QueryHandle
mkQueryHandle = QueryHandle
	<$> newQSem 1 -- only one query allowed at a time
	<*> mkEpsolarHandle
	<*> mkEpsolarStatusRegisterVector
	<*> mkEpsolarSingleValueRegisterVector
	<*> mkEpsolarSingleValueWideRegisterVector

runQuery :: QueryHandle -> IO a -> IO a
runQuery (QueryHandle lcksem _ _ _ _) a = bracket_ lock unlock a
  where
	lock = waitQSem lcksem
	unlock = signalQSem lcksem

-- This allows multiple queries to share data that's bundled together.
data QueryPass = QueryPass
	(MVar EpsolarStatus)
	(MVar EpsolarExtStatus)
	(MVar EpsolarOtherStatus)

queryPass :: (QueryPass -> IO a) -> IO a
queryPass a = do
	qp <- QueryPass
		<$> newEmptyMVar
		<*> newEmptyMVar
		<*> newEmptyMVar
	a qp

type QueryFailureCallback = SensedValue -> IO ()

epsolarQuery :: QueryHandle -> MVar a -> (Maybe a -> SensedValue) -> QueryFailureCallback -> (EpsolarHandle -> IO (Either String a)) -> IO SensedValue
epsolarQuery qh@(QueryHandle _ h _ _ _) mv mksensedvalue onfailure q =
	runQuery qh $ tryReadMVar mv >>= \case
		Just st -> return (mksensedvalue (Just st))
		Nothing -> do
			res <- try' (q h)
			case res of
				Right (Right st) -> do
					putMVar mv st
					return (mksensedvalue (Just st))
				Right (Left e) -> do
					hPutStrLn stderr e
					hFlush stderr
					failed
				Left e -> do
					hPutStrLn stderr (show e)
					hFlush stderr
					failed
  where
	failed = do
		let v = mksensedvalue Nothing
		onfailure v
		return v
	try' :: IO a -> IO (Either SomeException a)
	try' = try

query :: QueryHandle -> QueryPass -> GetSensedValue -> DataSourceFrom -> DataSource -> QueryFailureCallback -> IO SensedValue
query qh@(QueryHandle _ _ reg _ _) (QueryPass mv _ _) _ (EpsolarStatusValue mksensedvalue) _ onfailure =
	epsolarQuery qh mv mksensedvalue onfailure $ \ctx ->
		readEpsolarStatus ctx reg
query qh@(QueryHandle _ _ _ reg _) (QueryPass _ mv _) _ (EpsolarExtStatusValue mksensedvalue) _ onfailure =
	epsolarQuery qh mv mksensedvalue onfailure $ \ctx ->
		readEpsolarExtStatus ctx reg
query qh@(QueryHandle _ _ _ reg1 reg2) (QueryPass _ _ mv) _ (EpsolarOtherStatusValue mksensedvalue) _ onfailure =
	epsolarQuery qh mv mksensedvalue onfailure $ \ctx ->
		readEpsolarOtherStatus ctx reg1 reg2
query qh _ _ sensor@(OneWireSensor _) (DataSource _ (Just mksensedvalue) _ _) onfailure =
	runQuery qh (loop (2 :: Int))
  where
	loop n = do
		let f = oneWireSensorDataFile sensor
		res <- timeout 3000000 (try $ readFile f :: IO (Either IOException String))
		case res of
			Nothing -> readerr $ "timeout reading " ++ f
			Just (Left e) -> readerr $ "query for " ++ f ++ " failed: " ++ show e
			Just (Right s)
				| "YES" `isInfixOf` s -> 
					case map (readMaybe . dropWhile (not . numchar)) $ filter ("t=" `isPrefixOf`) (words s) of
						(Just temp:[]) -> do
							let tempc = temp / (1000 :: Double)
							if tempc < 500 && tempc > (-500)
								then return $ mksensedvalue $ show tempc
								else readerr $ "query for " ++ f ++ " returned absurd value " ++ show tempc
						_ -> readerr $ "query for " ++ f ++ " failed parse"
				| otherwise -> readerr $ "query for " ++ f ++ " failed CRC"
	  where
		numchar c = isNumber c || c == '-'
		readerr s = do
			hPutStrLn stderr s
			hFlush stderr
			let v = mksensedvalue ""
			onfailure v
			if n > 0
				then do
					threadDelay 1500000
					loop (n-1)
				else return v
query qh _ _ (SI7021 _match) (DataSource _ (Just mksensedvalue) _ _) onfailure = 
	runQuery qh (loop (2 :: Int))
  where
	loop _n = readerr "SI7021 disabled"
		{-
		timeout 3000000 (readProcessWithExitCode "./SI7021" [] "") >>= \case
		Nothing -> readerr "timeout reading from SI7021"
		Just (_exitcode, out, _err) ->
			case map (reverse . words) $ filter (match `isPrefixOf`) (lines out) of
				((w:_):[]) -> return $ mksensedvalue w
				_ -> readerr "SI7021 output parse failed"
		-}
	  where
		readerr s = do
			hPutStrLn stderr s
			hFlush stderr
			let v = mksensedvalue ""
			onfailure v
			return v
			{-
			if n > 0
				then do
					threadDelay 1500000
					loop (n-1)
				else return v
			-}
query _ _ getsensedvalue (StoredSensedValue k defv) (DataSource _ Nothing _ _) _ =
	fromMaybe defv <$> getsensedvalue k
query _ _ _ _ _ _ = error "bad data source definition!"

oneWireSensorDataFile :: DataSourceFrom -> FilePath
oneWireSensorDataFile (OneWireSensor sid) =
	"/sys/bus/w1/devices" </> sid </> "w1_slave"
oneWireSensorDataFile _ = ""

main :: IO ()
main = do
	linkSensors
	qh <- mkQueryHandle
	let postsensedvalue = postSensedValueCallback qh
	(webserverthread, addsensedvalue, getsensedvalue) <- runPollerWebserver postsensedvalue
	prep Frequent
	prep Infrequent
	void $ pollthread "Frequent query" (querier qh getsensedvalue addsensedvalue Frequent False)
		`concurrently` pollthread "Infrequent query" (querier qh getsensedvalue addsensedvalue Infrequent True)
		`concurrently` pollthread "trimetric" (Trimetric.Poller.pollTrimetric (Seconds 5) addsensedvalue getsensedvalue)
		`concurrently` pollthread "dhcp" (notifyDhcpClientChanges (addsensedvalue . DhcpClients))
		`concurrently` pollthread "darksky" (Darksky.Poller.pollForecast addsensedvalue)
		`concurrently` wait webserverthread
  where
	prep frequency = do
		let dsl = getFrequent frequency (dataSources mainStepLen)
		let fs = map (getFrequent frequency) (rrdFiles (allRras (getFrequent frequency mainStepLen)))
		forM_ fs $ \(rras, f) -> do
			e <- doesFileExist f
			if e
				then return ()
				else createRRD f (getFrequent frequency mainStepLen) dsl rras

	querier qh getsensedvalue addsensedvalue frequency waitbetween = do
		let dsl = getFrequent frequency (dataSources mainStepLen)
		go qh dsl getsensedvalue addsensedvalue frequency waitbetween

	go qh dsl getsensedvalue addsensedvalue frequency waitbetween = do
		let fs = map (getFrequent frequency) (rrdFiles (allRras (getFrequent frequency mainStepLen)))
		forM_ fs $ \(rras, f) -> do
			e <- doesFileExist f
			if e
				then return ()
				else createRRD f (getFrequent frequency mainStepLen) dsl rras

		pollstart <- getCurrentTime
		putStrLn $ show frequency ++ " query start"
		hFlush stdout
		let incfailure val = when (sensorFailed val) $
			sensorFailure getsensedvalue addsensedvalue
		sensed <- queryPass $ \qp ->
			forM dsl $ \(esv, ds) -> do
				val <- query qh qp getsensedvalue esv ds incfailure
				() <- addsensedvalue val
				return (ds, val)
		pollend <- getCurrentTime
		let elapsed = pollend `diffUTCTime` pollstart
		putStrLn $ show frequency ++ " query complete"
		hFlush stdout

		forM_ fs $ \(_, f) ->
			updateRRD f sensed
		putStrLn $ show frequency ++ " rrd update complete"
		hFlush stdout

		updateJsonForWebPage frequency pollstart sensed getsensedvalue
		putStrLn $ show frequency ++ " json update complete"
		hFlush stdout

		if waitbetween
			then do
				let (StepLen (Seconds goal)) = getFrequent frequency mainStepLen
				let delta = fromIntegral goal - elapsed
				putStrLn $ show frequency ++ " delaying: " ++ show delta
				hFlush stdout
				threadDelay $ floor $ 1000000 * delta
			else return ()

		go qh dsl getsensedvalue addsensedvalue frequency waitbetween

mainStepLen :: FreqPair StepLen
mainStepLen = FreqPair
	{ frequent = StepLen (Seconds 30)
	, infrequent = StepLen (Seconds 300)
	}

pollthread :: String -> IO () -> IO ()
pollthread name a = forever $ do
	r <- try' a
	case r of
		Left e -> hPutStrLn stderr $
			"thread " ++ name ++ " crashed: " ++ show e ++ "(will restart in 5 seconds)"
		Right () -> hPutStrLn stderr $
			"thread " ++ name ++ " exited (will restart in 5 seconds)"
	hFlush stderr
	threadDelaySeconds (Seconds 5)
  where
	try' :: IO a -> IO (Either SomeException a)
	try' = try
	
updateJsonForWebPage :: Frequency -> UTCTime -> [(DataSource, SensedValue)] -> GetSensedValue -> IO ()
updateJsonForWebPage frequency pollstart sensed getsensedvalue = do
	let jsname = case frequency of
		Frequent -> "frequent"
		Infrequent -> "infrequent"
	let jsfile = "rrds/recent" </> "data-" ++ jsname ++ ".js"
	let datapoints = map (\(DataSource rrdname _ _ _, val) -> (rrdname, formatSensedValue val)) sensed
	automationstatus <- getsensedvalue (keySensedValue AutomationOverallStatus)
		>>= return . \case
			Just (AutomationOverallStatus l) -> l
			_ -> []
	let fridgethoughts = Just $ concat $
		flip mapMaybe automationstatus $ \case
			FridgeThoughts t -> Just t
			_ -> Nothing
	let jsondatapoints = ("fridge_thoughts", fridgethoughts) : concatMap addFahrenheit datapoints
	writeFile (jsfile ++ ".new") $
		jsondata jsname (("lastpoll", Just (takeWhile (/= '.') (show pollstart))):jsondatapoints)
	renameFile (jsfile ++ ".new") jsfile
  where
	jsondata jsname l = 
		let inner = intercalate ", " $
			map (\(k, v) -> k ++ ": " ++ show (fromMaybe "unknown" v)) l
		in jsname ++ "={" ++ inner ++ "}"

addFahrenheit :: (String, Maybe String) -> [(String, Maybe String)]
addFahrenheit (k, v)
	| "celsius" `isSuffixOf` k =
		go (reverse (drop 7 (reverse k)) ++ "fahrenheit")
	| "_temp" `isSuffixOf` k = 
		go (k ++ "_fahrenheit")
	| otherwise = [(k, v)]
  where
	go kf = [ (k, v)
		, case readMaybe =<< v of
			Nothing -> (kf, Nothing)
			Just c -> (kf, Just $ show $ celsiusToFahrenheit (TemperatureCelsius c))
		]

postSensedValueCallback :: QueryHandle -> AddSensedValue -> SensedValue -> IO Bool
postSensedValueCallback qh addsensedvalue v = case v of
	-- Turn the charge controller load on/off.
	-- This is only here because of the poor quality of the
	-- interface to the charge controller prevents putting it into
	-- controller.hs
	CcLoadSetTo p -> do
		ok <- loadControl qh addsensedvalue p
		-- Forward back to the automation now that the load
		-- has been switched.
		if ok
			then addsensedvalue v
			else return ()
		return ok
	-- Let the SensedValue be forwarded back to the automation.
	-- This way, the automation can send us values for safekeeping,
	-- and when it's restarted, it can access the previous value.
	_ -> do
		addsensedvalue v
		return True

loadControl :: QueryHandle -> AddSensedValue -> PowerSetting -> IO Bool
loadControl qh@(QueryHandle _ h _ _ _) addsensedvalue powersetting = do
	res <- runQuery qh $
		withEpsolarContext h (\ctx -> setEpsolarLoad ctx powersetting)
			>>= return . \case
				Right () -> CcLoadControlWorking True
				_ -> CcLoadControlWorking False
	addsensedvalue res
	case res of
		CcLoadControlWorking True -> return True
		_ -> return False

-- | Make symlinks to sensor data files, for easy manual access.
linkSensors :: IO ()
linkSensors = do
	let ds = dataSources mainStepLen
	let w1sensors = filter (isw1 . fst) $
		getFrequent Frequent ds ++ getFrequent Infrequent ds
	createDirectoryIfMissing False "sensors"
	forM_ w1sensors $ \(sensor, DataSource name _ _ _) -> do
		let src = oneWireSensorDataFile sensor
		let dest = "sensors" </> name
		void $ try' $ removeLink dest
		createSymbolicLink src dest
  where
	isw1 (OneWireSensor _) = True
	isw1 _ = False

	try' :: IO a -> IO (Either SomeException a)
	try' = try
