import GPIO

-- Must run as root, ideally on boot..
main :: IO ()
main = setupGPIOPorts
