Last updated: 10/12/2021


'Version 1607' can be applied to version 1607 of Windows 10 Enterprise.
'Version 1703' can be applied to version 1703 of Windows 10 Enterprise.
'Version 1709' can be applied to version 1709 of Windows 10 Enterprise.
'Version 1803' can be applied to version 1803 of Windows 10 Enterprise.
'Version 1809' can be applied to version 1809 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 1903' can be applied to version 1903 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 1909' can be applied to version 1909 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 2004' can be applied to version 2004 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 20H2' can be applied to version 20H2 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 21H1' can be applied to version 21H1 of Windows 10 Enterprise, Windows Server Datacenter and Windows Server Standard.
'Version 21H2_Win10' can be applied to version 21H2 of Windows 10 Windows Server Datacenter and Windows Server Standard.
'Version 21H2_Win11' can be applied to version 21H2 of Windows 11 Enterprise, Windows Server Datacenter and Windows Server Standard.

==============================================================================

LGPO.exe is required to install the Restricted Traffic Limited Functionality package, so please follow the below instructions to download LGPO.exe:  

1. Download LGPO.zip from https://www.microsoft.com/en-us/download/details.aspx?id=55319
2. Extract LGPO.zip into the "Tools" folder into WindowsRTLFB\Tools\
3. Run PowerShell with administrator privilege.
4. Run RestrictedTrafficInstall.ps1.
5. Check the “\Logs” folder to make sure execution was successful 
6. Restart Windows 

Note: For Version 1607 Enterprise, background apps under path "Setting-Privacy-Background apps" need to be turned OFF manually.
