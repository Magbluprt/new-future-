
# This script is used to configure a machine for zero telemetry. 
# Note: These commands must be run from an elevated (admin) PowerShell. Also before running this script, user should wait for all the apps to get displayed under Background Apps (approx 30 mins).
# First, you may need to run: Set-ExecutionPolicy RemoteSigned
# The PowerShell Execution Policy should be set to RemoteSigned in order to allow local PowerShell scripts to be run.
# Make sure you run from the same directory as the GroupPolicy folder.

# Retrieve windows SKU by checking regestry first. https://msdn.microsoft.com/en-us/library/hh846315(v=vs.85).aspx

$serverVersionRegistry = "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Server\ServerLevels";
$invocationpath = Split-Path -parent $MyInvocation.MyCommand.Definition
$versionRegistry = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
$toolsPath= "$invocationpath\Tools"
$OSVersion = (Get-ItemProperty -path $versionRegistry).DisplayVersion
$CurrentBuild = (Get-ItemProperty -path $versionRegistry).CurrentBuild
$editionID = ""
$ADMXPath = ""
$cmd = ""

if($null -eq $OSVersion){
    $OSVersion = (Get-ItemProperty -path $versionRegistry).ReleaseId
}

if (!(Test-Path -Path $serverVersionRegistry))
{
    $editionID = (Get-ItemProperty -path $versionRegistry).EditionID;
}
else
{
    $serverLevels = Get-ItemProperty -path $serverVersionRegistry;
    if ($serverLevels."Server-Gui-Mgmt" -eq 1 -and $serverLevels."Server-Gui-Shell" -eq 1 -and $serverLevels.ServerCore -eq 1)
    {       
        $editionID = "ClientyServer"
    }    
}

Switch ($editionID)
{
    Enterprise 
    { 
        Write-Host "Windows Client Enterprise"
        $cmd = "Enterprise\RestrictedTraffic_ClientEnt_Install.cmd"        
    }

    ClientyServer    
    {
        Write-Host "Windows Server Client"    
        $cmd = "Server\RestrictedTraffic_ClientyServer_Install.cmd"
    }    
    
    Default 
    {
        Write-Error "Could not get SKU of current running OS."
        exit
    }

}

if ($OSVersion -eq "21H2") {
    if ($CurrentBuild -eq 22000) {
        $ADMXPath = "$invocationpath\Version 21H2_Win11\$cmd";
    }
    else{
        $ADMXPath = "$invocationpath\Version 21H2_Win10\$cmd";
    }
}
else{
    $ADMXPath = "$invocationpath\Version $OSVersion\$cmd";
}

if(Test-Path $ADMXPath){
    Invoke-Expression "& '$ADMXPath' $toolsPath";
}
else {
    Write-Error "Could not determine ADMX path."
    exit
}

